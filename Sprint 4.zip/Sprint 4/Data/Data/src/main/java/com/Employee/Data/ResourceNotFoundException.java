//package com.Employee.Data;
//
//public class ResourceNotFoundException {
//	
//	public ResourceNotFoundException (String message)
//	{
//		super(message);
//	}
//	public ResourceNotFoundException()
//	{
//		super("Resource not found");
//	}
//}
//
//
