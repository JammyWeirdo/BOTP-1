package com.Employee.Data;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	
   @Autowired
   private UserRepository userRepo;

	public UserData getUserById(int id) {
		// TODO Auto-generated method stub
		return userRepo.findById(id).get();
	}

	public UserData insertData(UserData data) {
		// TODO Auto-generated method stub
		return userRepo.save(data);
	}

	public List<UserData> getAll() {
		// TODO Auto-generated method stub
		return userRepo.findAll();
	}

//	public void deleteById(int id) {
//		// TODO Auto-generated method stub
//		 try
//		 {
//			 userRepo.deleteById(id);
//		 }
//		 catch(NullPointerException e)
//		 {
//			 throw new NullPointerException(e.getMessage());
//		 }
//	}
	
	
	public void deleteById(int id) {
	    if (userRepo == null) {
	        throw new NullPointerException("userRepo is null");
	    }

	    userRepo.deleteById(id);
	}


	public UserData updateUser(int id,UserData data) {
		// TODO Auto-generated method stub
		UserData user = userRepo.findById(id).get();
		user.setFirstname(data.getFirstname());
		user.setLastname(data.getLastname());
		user.setDepartment(data.getDepartment());
		return userRepo.save(user);
		
	}

	public static UserData saveUserData(UserData userData) {
		// TODO Auto-generated method stub
		return null;
	}
	
}


