package com.Employee.Data;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController
{
	@Autowired
	private UserService userService;
	
	@GetMapping(value="/getUserById/{id}")
	public UserData getUserById(@PathVariable("id") int id)
	{
	    return userService.getUserById(id);
	}
	@GetMapping(value="/getAll")
	public List<UserData> getAllUser()
	{
	    return userService.getAll();
	}
	
	@DeleteMapping(value="/deleteById/{id}")
	public String deleteById(@PathVariable("id") int id) throws NullPointerException
	{
	    try
	    {
	    	userService.deleteById(id);
	    }
	    catch(NullPointerException e)
	    {
	    	throw new NullPointerException(e.getMessage());
	    }
	    return "User Deleted Successfully";
	}
	
	@PostMapping(value="/insertData")
	public UserData insertData(@RequestBody UserData data)
	{
	    return userService.insertData(data);
	}
	
	@PutMapping(value="/UpdateData/{id}")
	public UserData updateUser(@PathVariable("id") int id,@RequestBody UserData data)
	{
	    return userService.updateUser(id,data);
	}
	
	

	
	
}