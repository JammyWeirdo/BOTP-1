package com.Employee.Data;

//public class UserServiceTest {

//}

//package com.yourcompany.employee.service;

import com.Employee.Data.UserData;
import com.Employee.Data.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class UserServiceTest {

    @Mock
    private UserRepository UserRepository;

    @InjectMocks
    private UserService UserService;

    @SuppressWarnings("deprecation")
	@BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSaveEmployee() {
        UserData employee = new UserData();
        when(UserRepository.save(any())).thenReturn(employee);

        UserData savedEmployee = UserService.saveUserData(new UserData());

        assertNotNull(savedEmployee);
        verify(UserRepository, times(1)).save(any());
    }

    // Similar tests for getEmployee, getAllEmployees, and deleteEmployee
}

