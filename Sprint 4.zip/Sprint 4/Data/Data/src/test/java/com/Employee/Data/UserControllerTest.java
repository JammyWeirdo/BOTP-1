package com.Employee.Data;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.beans.factory.annotation.Autowired;

@SpringBootTest
public class UserControllerTest {

    @Autowired
    private UserController userController;

    @Mock
    private UserService userService;

    @Test
    public void testGetUserById() {
        // Arrange
        int userId = 1;
        UserData expectedUser = new UserData(userId, "anu", "ghatage", "ddd");
        
        // Mock the userService.getUserById method
        when(userService.getUserById(userId)).thenReturn(expectedUser);

        // Act
        UserData actualUser = userController.getUserById(userId);

        // Assert
        assertEquals(expectedUser, actualUser);
    }
    
    
    @Test
    public void testGetAllUser() {
        // Create a list of dummy data for testing
        List<UserData> dummyData = Arrays.asList(new UserData(), new UserData());

        // Define the behavior of userService.getAll() when called
        when(userService.getAll()).thenReturn(dummyData);

        // Call the method to be tested
        List<UserData> result = userController.getAllUser();

        // Verify that userService.getAll() was called
        verify(userService, times(1)).getAll();

        // Verify that the result is as expected
        assertEquals(dummyData, result);
    }
    
    
    
    
}
