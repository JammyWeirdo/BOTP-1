package com.hotel.HotelService;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;




@RunWith(SpringRunner . class)
@SpringBootTest
class HotelMokitoTest {

	@Autowired
	private HotelService hotelservice;

	@MockBean
	private HotelRepository hotelrepository;

	@Test 
	public void getAllTest() {
	when(hotelrepository.findAll()).thenReturn((List<Hotel>) Stream.of(new Hotel(1,"anuja","pune"),new  Hotel(2,"hdb","ww")).collect(Collectors.toList()));
	assertEquals(2, hotelservice.getAll().size());
	
	}
	
//  @Test
// 	public void findByIdTest() {
// 		int id=2;
// 		when(hotelrepository.findById(id)).thenReturn((Stream.of(new Hotel(1,"anuja","pune").collect(Collectors.toList()))));
// 		assertEquals(1, hotelservice.get(id));
//	}

  

	 @Test 
		public void createhotelTest() {
		 Hotel hotel=new Hotel(1,"anu","ss");
		 when(hotelrepository.save(hotel)).thenReturn(hotel);
		 assertEquals(hotel,hotelservice.create(hotel));
	 }
	 
	 @Test
	 public void findByIdTest() {
		 Hotel hotel =new Hotel(2,"anu","ss");
		 hotelservice.get(1);
		 verify(hotelrepository,times(1)).findById(1);
		 
	 }
	 
	 
	 
	 
	
	

}
