package com.hotel.HotelService;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*; 
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.junit.jupiter.api.Test;

class controllertest {

	@Mock
	private HotelService hotelservice;
	
	@InjectMocks
	private HotelController hotelcontroller;

	private Hotel hotel;
	
	@BeforeEach
	void setup() {
		hotel = new Hotel();
		hotel.setId((int) (100));
		hotel.setName("ganesh");
		hotel.setLocation("Delhi");
		MockitoAnnotations.openMocks(this);
	}
	
	
	@Test
	void testcreate() {
		when(hotelservice.create(hotel)).thenReturn(hotel);
		ResponseEntity<Hotel> addResponse = hotelcontroller.createHotel(hotel);

		assertEquals(HttpStatus.CREATED,addResponse.getStatusCode());
		//sample
		assertEquals("ganesh",hotelservice.create(hotel).getName());
	}
	
	
	
	@Test
	void testFindAll() {
		List<Hotel> list = new ArrayList<>();
		Hotel user1 = new Hotel((int) 101, "heer", "mumbai");
		Hotel user2 = new Hotel((int) 102, "heer", "mumbai");
		list.add(user1);
		list.add(user2);
		when(hotelcontroller.getAll()).thenReturn((ResponseEntity<List<Hotel>>) list);
		assertEquals(HttpStatus.OK, hotelcontroller.getAll().getStatusCode());
		assertEquals(2,((List<Hotel>) hotelcontroller.getAll()).size());
	}
	}


