package com.hotel.HotelService;
import java.util.List;

public interface HotelService {
	
	//create
	
	Hotel create (Hotel hotel);
	

	
	//getaall
	
	List<Hotel>getAll();
	
	
	//getsingle 
	Hotel get(int id);

}
