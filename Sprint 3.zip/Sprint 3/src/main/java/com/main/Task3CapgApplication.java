package com.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Task3CapgApplication {

	public static void main(String[] args) {
		SpringApplication.run(Task3CapgApplication.class, args);
	}

}
