package com.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.main.service.TaskService;

@RestController
public class TaskController {
	
	@Autowired
	private TaskService service;
	
	@GetMapping(value="/addTwoNumbers/{first}/{second}")
	public ResponseEntity<?> addTwoNumbers(@PathVariable("first") int first,@PathVariable("second") int second)
	{
		int res=service.addTwoNumbers(first,second);
		
		if(res>0)
		{
			return new ResponseEntity<>(res,HttpStatus.OK);
		}
		return new ResponseEntity<>("Numbers should be positive",HttpStatus.BAD_GATEWAY);
	}
	
	
	@GetMapping(value="/subTwoNumbers/{first}/{second}")
	public ResponseEntity<?> subTwoNumbers(@PathVariable("first") int first,@PathVariable("second") int second)
	{
		System.out.println("******************first level****************");
		int res=service.subTwoNumbers(first,second);
		
		if(res>0)
		{
			return new ResponseEntity<>(res,HttpStatus.OK);
		}
		return new ResponseEntity<>("Numbers should be positive",HttpStatus.BAD_GATEWAY);
	}
	
	@GetMapping(value="/fibonacci/{n}")
	public ResponseEntity<?> fibonacci(@PathVariable("n") int n)
	{
		System.out.println("******************first level****************");
		List<Integer> list=service.fibonacci(n);
		return new ResponseEntity<>(list,HttpStatus.OK);
		
	}
	
	@GetMapping(value="/checkPalindrome/{n}")
	public ResponseEntity<?> checkPalindrome(@PathVariable("n") String str)
	{
		System.out.println("******************first level****************");
		boolean res=service.checkPalindrome(str);
		return new ResponseEntity<>(res,HttpStatus.OK);
		
	}

	@GetMapping(value="/areAnagram/{n1}/{n2}")
	public ResponseEntity<?> areAnagram(@PathVariable("n1") String str1,@PathVariable("n2") String str2)
	{
		System.out.println("******************first level****************");
		boolean res=TaskService.areAnagram(str1,str2);
		return new ResponseEntity<>(res,HttpStatus.OK);
		
	}

}
