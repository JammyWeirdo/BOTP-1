package com.main.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;

public class AnagramControllerTest {

	    @Test
	    public void testAreAnagram_WhenAnagram_ReturnsTrue() {
	        TaskController controller = new TaskController(); // Instantiate your controller here
	        ResponseEntity<?> responseEntity = controller.areAnagram("listen", "silent");
	        boolean result = (boolean) responseEntity.getBody();
	        assertEquals(true, result);
	    }

	    @Test
	    public void testAreAnagram_WhenNotAnagram_ReturnsFalse() {
	        TaskController controller = new TaskController(); // Instantiate your controller here
	        ResponseEntity<?> responseEntity = controller.areAnagram("hello", "world");
	        boolean result = (boolean) responseEntity.getBody();
	        assertEquals(false, result);
	    }

	    @Test
	    public void testAreAnagram_WhenOneStringIsEmpty_ReturnsFalse() {
	        TaskController controller = new TaskController(); // Instantiate your controller here
	        ResponseEntity<?> responseEntity = controller.areAnagram("", "test");
	        boolean result = (boolean) responseEntity.getBody();
	        assertEquals(false, result);
	    }

	    @Test
	    public void testAreAnagram_WhenBothStringsAreEmpty_ReturnsTrue() {
	        TaskController controller = new TaskController(); // Instantiate your controller here
	        ResponseEntity<?> responseEntity = controller.areAnagram("", "");
	        boolean result = (boolean) responseEntity.getBody();
	        assertEquals(true, result);
	    }
	}
