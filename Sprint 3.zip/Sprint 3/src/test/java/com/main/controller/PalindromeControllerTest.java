package com.main.controller;

import com.main.controller.TaskController;
import com.main.service.TaskService;
//import com.main.service.checkPalindrome;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

 

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

 

public class PalindromeControllerTest {

 

    @Mock
    private TaskService Service;

 

    @InjectMocks
    private TaskController palindromeController;

 

    @Test
    public void testPalindromeEndpointWithPalindromeString() throws Exception {
        String inputString = "racecar";
        Mockito.when(TaskService.isPalindrome(inputString)).thenReturn(true);

 

        MockMvc mockMvc = MockMvcBuilders.standaloneSetup(palindromeController).build();

 

        mockMvc.perform(get("/checkPalindrome/{n}", inputString))
                .andExpect(status().isOk())
                .andExpect(content().string("true"));
    }

 

    @Test
    public void testPalindromeEndpointWithNonPalindromeString() throws Exception {
        String inputString = "hello";
        Mockito.when(TaskService.checkPalindrome(inputString)).thenReturn(false);

 

        MockMvc mockMvc = MockMvcBuilders.standaloneSetup(palindromeController).build();

 

        mockMvc.perform(get("/checkPalindrome/{n}", inputString))
                .andExpect(status().isOk())
                .andExpect(content().string("false"));
    }
}