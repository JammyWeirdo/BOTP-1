package com.main.controller;

import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.main.service.TaskService;

public class AddTwoNumbersTest {
	
	 @Test
	    public void testAddTwoNumbers_PositiveNumbers() {
	        int first = 5;
	        int second = 3;
	        int expectedResult = 8;

	        Mockito.when(TaskService.addTwoNumbers(first, second)).thenReturn(expectedResult);

	        ResponseEntity<?> responseEntity;
			try {
				responseEntity = TaskController.addTwoNumbers(first, second);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	        assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
	        assertEquals(expectedResult, responseEntity.getBody());
	    }

	    @Test
	    public void testAddTwoNumbers_NegativeNumbers() {
	        int first = -5;
	        int second = 3;

	        Mockito.when(TaskService.addTwoNumbers(first, second)).thenReturn(-1);

	        ResponseEntity<?> responseEntity;
			try {
				responseEntity = TaskController.addTwoNumbers(first, second);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	        assertEquals(HttpStatus.BAD_GATEWAY, responseEntity.getStatusCode());
	        assertEquals("Numbers should be positive", responseEntity.getBody());
	    }

}
