package com.main.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.main.service.TaskService;

public class FibonacciControllerTest {
	
	
	   @InjectMocks
	   private TaskController fibonacciController;

	    @Mock
	    private TaskService  service;

	    @BeforeEach
	    public void setUp() {
	        MockitoAnnotations.initMocks(this);
	    }

	    @Test
	    public void testFibonacciWithValidInput() {
	        int n = 5;
	        List<Integer> expectedFibonacciSequence = Arrays.asList(0, 1, 1, 2, 3, 5);

	        when(service.fibonacci(n)).thenReturn(expectedFibonacciSequence);

	        ResponseEntity<?> response = fibonacciController.fibonacci(n);
	        assertEquals(expectedFibonacciSequence, response.getBody());
	    }

	    @Test
	    public void testFibonacciWithNegativeInput() {
	        int n = -5;

	        when(service.fibonacci(n)).thenReturn(null);

	        ResponseEntity<?> response = fibonacciController.fibonacci(n);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertEquals(null, response.getBody());
	    }

}
